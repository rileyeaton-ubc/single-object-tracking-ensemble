# KCF
python implementation of "high-speed tracking with kernelized correlation filters"
### Introduction
This is a python implementation of KCF tracker.
The main purpose of this project is to help you understand KCF pipeline, so the details are not exactly the same as the paper.
